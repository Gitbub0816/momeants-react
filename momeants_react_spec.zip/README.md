# Momeants React / Expo Specification

Momeants is a visually premium, cross-platform memory-sharing app built around single-photo moments, real-world relationships, and emotional resurfacing.

See:
- docs/visual_style.md
- docs/app_structure.md
- docs/screen_rules.md
- docs/component_contracts.md
- docs/build_rules.md
