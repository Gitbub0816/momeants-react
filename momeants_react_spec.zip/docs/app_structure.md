# Momeants App Structure

## Architecture
```txt
apps/
  mobile/          Expo React Native app
  web/             Next.js web app
  admin/           Next.js internal/admin app

packages/
  core/            product logic
  api-client/      typed API client
  types/           shared TypeScript types
  design/          tokens and primitives
  media/           upload/compression helpers
  animations/      Rive/Lottie files and wrappers
  config/          env and flags
```

## Mobile Routing
```txt
app/
  _layout.tsx
  (auth)/
    sign-in.tsx
    create-account.tsx
  onboarding/
    welcome.tsx
    identity.tsx
    birthday.tsx
    username.tsx
    location.tsx
    avatar.tsx
    permissions.tsx
    connect.tsx
  (tabs)/
    _layout.tsx
    home.tsx
    timeline.tsx
    circle.tsx
    profile.tsx
  capture/
    index.tsx
    edit.tsx
    details.tsx
    privacy.tsx
    share.tsx
  moment/
    [id].tsx
```

## Shared Types
```ts
export type MomentVisibility = 'private' | 'close_circle' | 'selected_people';

export type MoodTag =
  | 'peaceful'
  | 'grateful'
  | 'loved'
  | 'excited'
  | 'nostalgic'
  | 'proud'
  | 'free'
  | 'cozy'
  | 'adventurous';

export interface Moment {
  id: string;
  ownerId: string;
  imageUrl: string;
  caption?: string;
  capturedAt: string;
  createdAt: string;
  visibility: MomentVisibility;
  moodTags: MoodTag[];
  peopleIds: string[];
  place?: MomentPlace;
  resurfacingEligible: boolean;
  likeCount: number;
  commentCount: number;
}
```

## Build Order
1. Design tokens and base components
2. Auth and onboarding
3. Capture flow
4. Moment detail screen
5. Home memory surface
6. Timeline
7. Close circle
8. Profile
9. Notifications
10. Resurfacing
11. Web share pages
12. Admin moderation
