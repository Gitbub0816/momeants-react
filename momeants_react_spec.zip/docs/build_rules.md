# Momeants Build Rules

## Stack
- Expo React Native for mobile
- Next.js for web/admin
- TypeScript everywhere
- Expo Router
- Reanimated + Gesture Handler
- Expo Image, Camera, Image Picker, Haptics, Notifications, Linear Gradient
- Skia only where it earns its keep

## Product Rule
Build the emotional memory loop first:
```txt
Capture photo
Add emotional context
Choose privacy
Save/share
Relive later
```

## TypeScript
Use strict TypeScript. Shared types go in packages/types. API responses must be typed. Avoid `any`.

## Design
Use shared tokens. Do not hard-code random colors, spacing, radii, or card styles.

## Performance
- thumbnails in lists
- full images in detail views
- cached image loading
- UI-thread animations
- avoid heavy media work on JS thread
- avoid blur/glass in long scrolling lists

## Accessibility
- icon buttons need labels
- readable text over images
- 44x44 tap targets
- support reduced motion
- do not rely on color alone

## Backend
Early backend can be Firebase. Later can move to Neon/Postgres + Cloudflare/R2. Keep product logic behind API abstractions.

```ts
export interface MomentsApi {
  createMoment(input: CreateMomentInput): Promise<Moment>;
  getMoment(id: string): Promise<Moment>;
  listHomeMoments(): Promise<Moment[]>;
  listTimeline(params: TimelineParams): Promise<TimelineGroup[]>;
}
```

## MVP Order
1. Project setup
2. Design tokens
3. Base components
4. Auth
5. Onboarding
6. Capture photo flow
7. Save moment
8. Home hero card
9. Moment detail
10. Timeline
11. Circle sharing
12. Profile
13. Resurfacing
14. Notifications
15. Web share page

## Final Rule
React Native / Expo is capable of the visual quality Momeants needs. The risk is inconsistent design discipline, not the framework.
