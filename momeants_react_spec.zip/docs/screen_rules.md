# Momeants Screen Rules

## Screenshot Note
The generated screenshot nailed the style but not the final layout. Keep the dark glossy cinematic styling, glowing accents, glass surfaces, emotional photos, refined typography, and floating capture button. Fix the density.

## Navigation
Primary tabs:
```txt
Home
Timeline
Capture
Circle
You
```

## Home
Purpose: show what matters today.

Layout:
```txt
Header: greeting, small wordmark, notifications
Hero: one dominant memory or resurfaced memory
Close Circle: small row of meaningful people
Secondary: recent or resurfaced moments
Bottom: floating glass tab bar
```

## Capture
Purpose: make saving a memory beautiful and fast.

Steps:
```txt
1. Select/capture photo
2. Add feeling/mood
3. Add optional caption
4. Add people/place/music if desired
5. Choose privacy
6. Save/share
```

## Moment Detail
Full-screen photo with gradient overlay. Show caption, date, mood tags, people, place, gentle reactions, and comments. The photo should dominate.

## Timeline
A chronological memory browser grouped by date, month, and year. It should feel like a life thread, not an endless feed.

## Circle
Manage close relationships and view meaningful shared memories. Avoid influencer language like followers, fans, or reach.

## Profile
Profile should be personal memory identity, not social status. Prioritize moments, days remembered, people close, moods, and albums.

## Onboarding
Fields:
```txt
phone or email, one required
full name
DOB / age confirmation
avatar
username / display name
city/state/province/country
optional connect step
legal consent
```

## Resurfacing
Bring old moments back at the right time. Let users hide people, places, or date ranges from resurfacing. Make the feature adjustable and gentle.

## Anti-Patterns
Do not build crowded dashboard home, Explore-first homepage, endless public feed as core UX, leaderboards, follower-count obsession, or cards on cards on cards.
