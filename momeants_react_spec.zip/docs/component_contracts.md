# Momeants Component Contracts

## Foundation
- ScreenShell
- GlassCard
- GradientText
- MomeantsButton
- IconPill

## Navigation
- MomeantsTabBar
- CaptureButton

## Memory
- MemoryHeroCard
- MemoryMiniCard
- MomentDetailView
- MoodPill
- MoodSelector

## Capture
- CaptureComposer
- ImageCaptureSurface
- MomentPromptInput
- MomentPrivacyPicker
- PeoplePicker
- PlacePicker

## Circle
- CircleAvatar
- CloseCircleStrip
- CircleMomentCard

## Timeline
- TimelineDateRail
- TimelineMomentRow
- MonthJumpPicker

## Profile
- ProfileHeader
- MemoryStats
- MoodSummary
- PeopleMemoryStrip

## Resurfacing
- ResurfacedMemoryCard
- ResurfacingControls

## Animation
- FloatingHearts
- SparkleBurst
- ParallaxImageHeader

## Rule
Every component should help the user capture, relive, organize, or share a meaningful memory. If not, do not build it yet.
