# Momeants Visual Style

## Direction
Momeants should feel like a cinematic memory box: dark, glossy, emotional, intimate, premium, and photographic.

The generated screenshot captured the correct style language: glowing purple accents, soft glass, deep navy-black backgrounds, emotional imagery, elegant type, and a magical-but-grown-up feel. Keep that style. The screenshot layout itself was too crowded and dashboard-like, so the final app must be calmer, more focused, and more memory-first.

## Brand Feel
Momeants should feel emotional, premium, cinematic, intimate, magical, modern, and calm. Avoid generic SaaS dashboards, crowded grids, Instagram-clone layouts, crypto/neon-gaming aesthetics, or harsh dark mode.

## Color System

```ts
export const colors = {
  ink900: '#050711',
  ink850: '#090C18',
  ink800: '#0E1324',
  ink700: '#151B31',

  glass900: 'rgba(12, 16, 32, 0.72)',
  glass800: 'rgba(22, 28, 50, 0.58)',
  glass700: 'rgba(255, 255, 255, 0.08)',

  textPrimary: '#F8F4FF',
  textSecondary: 'rgba(248, 244, 255, 0.72)',
  textMuted: 'rgba(248, 244, 255, 0.48)',

  auraPurple: '#B57CFF',
  auraPink: '#FF7AC8',
  auraBlue: '#78A7FF',
  auraLavender: '#D8C2FF',

  sunsetPeach: '#FFB38A',
  emberRose: '#FF6E91',
  candleGold: '#FFD28A',

  love: '#FF6E91',
  private: '#9CE6D3',
  safe: '#7BE7C8',
  warning: '#FFD28A',
  danger: '#FF6B7A',
};
```

## Background
The app background should never be plain black. Use deep navy with subtle radial glow.

```tsx
<LinearGradient
  colors={['#151B31', '#090C18', '#050711']}
  start={{ x: 0.1, y: 0 }}
  end={{ x: 0.9, y: 1 }}
  style={StyleSheet.absoluteFill}
/>
```

## Typography
Use a refined serif for emotional headings and wordmark-style moments, paired with a clean sans for UI.

Recommended:
- Display: Playfair Display, Cormorant Garamond, or similar
- UI: Inter, SF Pro, or system sans

```ts
export const typography = {
  displayXL: { fontSize: 44, lineHeight: 50, letterSpacing: -0.8 },
  display: { fontSize: 34, lineHeight: 40, letterSpacing: -0.4 },
  title: { fontSize: 24, lineHeight: 30, letterSpacing: -0.2 },
  section: { fontSize: 19, lineHeight: 25, fontWeight: '600' },
  body: { fontSize: 16, lineHeight: 23 },
  caption: { fontSize: 13, lineHeight: 18 },
};
```

## Layout
Correct structure:
```txt
Top: calm header / greeting / current emotional context
Middle: one dominant memory or capture action
Lower: close circle / resurfacing / timeline preview
Bottom: simple tab bar with centered capture button
```

Do not show six panels at once. Momeants should breathe.

## Glass Card
```tsx
export function GlassCard({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.075)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.13)',
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 14 },
    overflow: 'hidden',
  },
});
```

## Memory Card
```tsx
<View style={styles.memoryCard}>
  <Image source={{ uri: imageUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
  <LinearGradient
    colors={['rgba(0,0,0,0.05)', 'rgba(5,7,17,0.35)', 'rgba(5,7,17,0.82)']}
    style={StyleSheet.absoluteFill}
  />
  <View style={styles.memoryContent}>
    <Text style={styles.memoryDate}>MAY 20</Text>
    <Text style={styles.memoryTitle}>Golden hour hikes with the best company</Text>
    <MoodPills moods={['Peaceful', 'Grateful']} />
  </View>
</View>
```

## Bottom Navigation
Tabs should be:
```txt
Home
Timeline
Capture
Circle
You
```
Avoid making Explore a primary early tab.

## Motion
Use gentle spring cards, slow parallax image headers, fade/scale transitions, small floating hearts, subtle sparkle on save, and haptics for capture/save/tag actions.
